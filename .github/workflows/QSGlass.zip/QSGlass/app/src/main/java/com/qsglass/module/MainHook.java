package com.qsglass.module;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.view.View;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Tahap 1: tile kaca + blur panel untuk SystemUI OxygenOS 15.
 * Semua hook dibungkus try/catch. Kalau ada yang gagal, hanya fitur itu yang mati
 * dan alasannya muncul di log LSPosed (cari tag [QSGlass]).
 */
public class MainHook implements IXposedHookLoadPackage {

    // ===== Pengaturan (ubah di sini lalu build ulang) =====
    static final boolean ENABLE_TILES = true;
    static final boolean ENABLE_BLUR = true;
    static final boolean FORCE_BLUR_SUPPORT = true;   // paksa supportsBlursOnWindows = true
    static final float BLUR_SCALE = 1.5f;             // pengali radius blur
    static final int BLUR_MAX_PX = 300;               // batas atas radius blur
    static final int ACCENT = 0xFF2F7CF6;             // warna ikon tile aktif
    static final float TILE_RADIUS = 999f;            // sangat besar = pil/lingkaran penuh
    // =======================================================

    static final String PKG = "com.android.systemui";
    static final String TILE = "com.android.systemui.qs.tileimpl.QSTileViewImpl";
    static final String ICON = "com.android.systemui.qs.tileimpl.QSIconViewImpl";
    static final String BLUR = "com.android.systemui.statusbar.BlurUtils";

    static final int STATE_UNAVAILABLE = 0, STATE_INACTIVE = 1, STATE_ACTIVE = 2;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!PKG.equals(lp.packageName)) return;
        ClassLoader cl = lp.classLoader;
        log("loaded in SystemUI, process=" + lp.processName);

        if (ENABLE_TILES) {
            safe("tile colors", () -> hookTileColors(cl));
            safe("tile shape", () -> hookTileShape(cl));
            safe("icon color", () -> hookIconColor(cl));
        }
        if (ENABLE_BLUR) {
            safe("blur", () -> hookBlur(cl));
        }
    }

    // ---------- Tile ----------
    private void hookTileColors(ClassLoader cl) {
        Class<?> c = XposedHelpers.findClass(TILE, cl);

        hook(c, "getBackgroundColorForState", new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                Integer s = stateOf(p.args);
                if (s == null) return;
                boolean dark = isDark(((View) p.thisObject).getContext());
                int color;
                if (s == STATE_ACTIVE) color = dark ? 0xEBFFFFFF : ACCENT;
                else if (s == STATE_INACTIVE) color = dark ? 0x38FFFFFF : 0x80FFFFFF;
                else color = dark ? 0x1FFFFFFF : 0x40FFFFFF;
                p.setResult(color);
            }
        });

        XC_MethodHook label = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                Integer s = stateOf(p.args);
                if (s == null) return;
                boolean dark = isDark(((View) p.thisObject).getContext());
                boolean secondary = "getSecondaryLabelColorForState".equals(p.method.getName());
                int base;
                if (s == STATE_ACTIVE) base = dark ? 0x000000 : 0xFFFFFF;
                else base = dark ? 0xFFFFFF : 0x000000;
                int alpha = (s == STATE_UNAVAILABLE) ? 0x66 : (secondary ? 0xB3 : 0xFF);
                p.setResult((alpha << 24) | base);
            }
        };
        hook(c, "getLabelColorForState", label);
        hook(c, "getSecondaryLabelColorForState", label);
    }

    private void hookTileShape(ClassLoader cl) {
        Class<?> c = XposedHelpers.findClass(TILE, cl);

        // Sudut pil/lingkaran penuh
        hook(c, "changeCornerRadius", new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                if (p.args.length == 1 && p.args[0] instanceof Float) p.args[0] = TILE_RADIUS;
            }
        });

        // Tepi tipis berkilau
        hook(c, "createTileBackground", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                try {
                    Object r = p.getResult();
                    if (!(r instanceof LayerDrawable)) return;
                    Context ctx = ((View) p.thisObject).getContext();
                    int id = ctx.getResources().getIdentifier("background", "id", PKG);
                    if (id == 0) return;
                    Drawable d = ((LayerDrawable) r).findDrawableByLayerId(id);
                    if (d instanceof GradientDrawable) {
                        int w = Math.max(1, Math.round(ctx.getResources().getDisplayMetrics().density));
                        int col = isDark(ctx) ? 0x40FFFFFF : 0x66FFFFFF;
                        ((GradientDrawable) d).setStroke(w, col);
                    }
                } catch (Throwable t) {
                    log("stroke failed: " + t);
                }
            }
        });
    }

    private void hookIconColor(ClassLoader cl) {
        Class<?> c = XposedHelpers.findClass(ICON, cl);
        hook(c, "getIconColorForState", new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                Integer s = stateOf(p.args);
                if (s == null) return;
                boolean dark = isDark(((View) p.thisObject).getContext());
                if (s == STATE_ACTIVE) p.setResult(dark ? ACCENT : 0xFFFFFFFF);
            }
        });
    }

    // ---------- Blur ----------
    private void hookBlur(ClassLoader cl) {
        Class<?> c = XposedHelpers.findClass(BLUR, cl);

        if (FORCE_BLUR_SUPPORT) {
            hook(c, "supportsBlursOnWindows", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) { p.setResult(true); }
            });
        }

        // applyBlur(ViewRootImpl, int radius, boolean opaque)
        hook(c, "applyBlur", new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                if (p.args.length >= 3 && p.args[1] instanceof Integer) {
                    int r = (Integer) p.args[1];
                    if (r > 0) p.args[1] = Math.min(BLUR_MAX_PX, Math.round(r * BLUR_SCALE));
                }
                if (p.args.length >= 3 && p.args[2] instanceof Boolean) p.args[2] = false;
            }
        });
    }

    // ---------- Util ----------
    private static Integer stateOf(Object[] args) {
        if (args == null) return null;
        for (Object a : args) {
            if (a instanceof Integer) return (Integer) a;
            if (a != null && !(a instanceof Context) && !(a instanceof Boolean)) {
                try { return XposedHelpers.getIntField(a, "state"); } catch (Throwable ignored) { }
            }
        }
        return null;
    }

    private static boolean isDark(Context c) {
        return (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    private static void hook(Class<?> c, String name, XC_MethodHook cb) {
        int n = XposedBridge.hookAllMethods(c, name, cb).size();
        log((n > 0 ? "OK   " : "MISS ") + c.getSimpleName() + "." + name + " (" + n + ")");
    }

    private static void safe(String what, Runnable r) {
        try { r.run(); } catch (Throwable t) { log("FAIL " + what + ": " + t); }
    }

    private static void log(String m) { XposedBridge.log("[QSGlass] " + m); }
}
