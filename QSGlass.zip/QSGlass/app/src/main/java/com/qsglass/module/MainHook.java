package com.qsglass.module;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.view.View;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Tahap 1: tile kaca + blur panel untuk SystemUI OxygenOS 15.
 * Semua hook dibungkus try/catch. Kalau ada yang gagal, hanya fitur itu yang mati
 * dan alasannya muncul di log LSPosed (cari tag [QSGlass]).
 */
public class MainHook implements IXposedHookLoadPackage {

    // ===== Pengaturan (ubah di sini lalu build ulang) =====
    static final boolean ENABLE_TILES = true;
    static final boolean ENABLE_BLUR = true;
    static final boolean FORCE_BLUR_SUPPORT = true;   // paksa supportsBlursOnWindows = true
    static final float BLUR_SCALE = 1.5f;             // pengali radius blur
    static final int BLUR_MAX_PX = 300;               // batas atas radius blur
    static final int ACCENT = 0xFF2F7CF6;             // warna ikon tile aktif
    static final float TILE_RADIUS = 999f;            // sangat besar = pil/lingkaran penuh
    // =======================================================

    static final String PKG = "com.android.systemui";
    static final String TILE = "com.android.systemui.qs.tileimpl.QSTileViewImpl";
    static final String ICON = "com.android.systemui.qs.tileimpl.QSIconViewImpl";
    static final String BLUR = "com.android.systemui.statusbar.BlurUtils";

    static final int STATE_UNAVAILABLE = 0, STATE_INACTIVE = 1, STATE_ACTIVE = 2;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!PKG.equals(lp.packageName)) return;
        ClassLoader cl = lp.classLoader;
        log("loaded in SystemUI, process=" + lp.processName);

        if (ENABLE_TILES) {
            safe("oplus tiles", () -> hookOplusTiles(cl));
            safe("tile colors", () -> hookTileColors(cl));
            safe("tile shape", () -> hookTileShape(cl));
            safe("icon color", () -> hookIconColor(cl));
        }
        if (ENABLE_BLUR) {
            safe("blur", () -> hookBlur(cl));
        }
    }

    // ---------- Tile versi Oplus (yang benar-benar dipakai OxygenOS) ----------
    static final String BG_NORMAL = "com.oplus.systemui.qs.base.widget.NormalOnePlusColorTileViewBackground";
    static final String BG_MIX = "com.oplus.systemui.qs.base.widget.MixColorOnePlusTileViewBackground";
    static final String BG_BASE = "com.oplus.systemui.qs.base.widget.BaseTileViewBackground";
    static final String OTV = "com.oplus.systemui.plugins.qs.tile.OplusQSTileView";
    static final String OTV_IMPL = "com.oplus.systemui.qs.tileimpl.OplusQSTileViewImpl";

    private void hookOplusTiles(ClassLoader cl) {
        // Warna tile tidak aktif / tidak tersedia -> semi-transparan (sudah pasti int, aman)
        Class<?> n = XposedHelpers.findClass(BG_NORMAL, cl);
        hook(n, "obtainColorForInactive", new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                Context c = (p.args.length > 0 && p.args[0] instanceof Context) ? (Context) p.args[0] : null;
                p.setResult(c != null && !isDark(c) ? 0x80FFFFFF : 0x38FFFFFF);
            }
        });
        hook(n, "obtainColorForUnavailable", new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                Context c = (p.args.length > 0 && p.args[0] instanceof Context) ? (Context) p.args[0] : null;
                p.setResult(c != null && !isDark(c) ? 0x40FFFFFF : 0x1FFFFFFF);
            }
        });

        // Diagnostik: lihat nilai asli yang dipakai Oplus (tidak mengubah apa pun)
        trace(cl, BG_BASE, "updateBackground");
        trace(cl, BG_MIX, "toActiveBackground");
        trace(cl, BG_MIX, "toInactiveBackground");
        trace(cl, BG_MIX, "toActiveDarkThemeBackground");
        trace(cl, BG_MIX, "toInactiveDarkThemeBackground");
        trace(cl, BG_MIX, "obtainColorForBgState");
        trace(cl, BG_MIX, "ensureAutoBlurDrawable");
        trace(cl, OTV_IMPL, "updateTextColor");

        // Tepi berkilau pada drawable background tile
        XC_MethodHook bgHook = new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                try {
                    Object r = p.getResult();
                    logLimited("bgdrawable", "getBackgroundDrawable -> " + (r == null ? "null" : r.getClass().getName()));
                    Context ctx = ((View) p.thisObject).getContext();
                    int w = Math.max(1, Math.round(ctx.getResources().getDisplayMetrics().density));
                    int col = isDark(ctx) ? 0x40FFFFFF : 0x66FFFFFF;
                    if (r instanceof GradientDrawable) {
                        ((GradientDrawable) r).setStroke(w, col);
                    } else if (r instanceof LayerDrawable) {
                        LayerDrawable ld = (LayerDrawable) r;
                        for (int i = 0; i < ld.getNumberOfLayers(); i++) {
                            Drawable d = ld.getDrawable(i);
                            if (d instanceof GradientDrawable) ((GradientDrawable) d).setStroke(w, col);
                        }
                    }
                } catch (Throwable t) {
                    log("oplus stroke failed: " + t);
                }
            }
        };
        hook(XposedHelpers.findClass(OTV, cl), "getBackgroundDrawable", bgHook);
        hook(XposedHelpers.findClass(OTV_IMPL, cl), "getBackgroundDrawable", bgHook);
    }

    // ---------- Tile ----------
    private void hookTileColors(ClassLoader cl) {
        Class<?> c = XposedHelpers.findClass(TILE, cl);

        hook(c, "getBackgroundColorForState", new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                Integer s = stateOf(p.args);
                if (s == null) return;
                boolean dark = isDark(((View) p.thisObject).getContext());
                int color;
                if (s == STATE_ACTIVE) color = dark ? 0xEBFFFFFF : ACCENT;
                else if (s == STATE_INACTIVE) color = dark ? 0x38FFFFFF : 0x80FFFFFF;
                else color = dark ? 0x1FFFFFFF : 0x40FFFFFF;
                p.setResult(color);
            }
        });

        XC_MethodHook label = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                Integer s = stateOf(p.args);
                if (s == null) return;
                boolean dark = isDark(((View) p.thisObject).getContext());
                boolean secondary = "getSecondaryLabelColorForState".equals(p.method.getName());
                int base;
                if (s == STATE_ACTIVE) base = dark ? 0x000000 : 0xFFFFFF;
                else base = dark ? 0xFFFFFF : 0x000000;
                int alpha = (s == STATE_UNAVAILABLE) ? 0x66 : (secondary ? 0xB3 : 0xFF);
                p.setResult((alpha << 24) | base);
            }
        };
        hook(c, "getLabelColorForState", label);
        hook(c, "getSecondaryLabelColorForState", label);
    }

    private void hookTileShape(ClassLoader cl) {
        Class<?> c = XposedHelpers.findClass(TILE, cl);

        // Sudut pil/lingkaran penuh
        hook(c, "changeCornerRadius", new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                if (p.args.length == 1 && p.args[0] instanceof Float) p.args[0] = TILE_RADIUS;
            }
        });

        // Tepi tipis berkilau
        hook(c, "createTileBackground", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                try {
                    Object r = p.getResult();
                    if (!(r instanceof LayerDrawable)) return;
                    Context ctx = ((View) p.thisObject).getContext();
                    int id = ctx.getResources().getIdentifier("background", "id", PKG);
                    if (id == 0) return;
                    Drawable d = ((LayerDrawable) r).findDrawableByLayerId(id);
                    if (d instanceof GradientDrawable) {
                        int w = Math.max(1, Math.round(ctx.getResources().getDisplayMetrics().density));
                        int col = isDark(ctx) ? 0x40FFFFFF : 0x66FFFFFF;
                        ((GradientDrawable) d).setStroke(w, col);
                    }
                } catch (Throwable t) {
                    log("stroke failed: " + t);
                }
            }
        });
    }

    private void hookIconColor(ClassLoader cl) {
        Class<?> c = XposedHelpers.findClass(ICON, cl);
        hook(c, "getIconColorForState", new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                Integer s = stateOf(p.args);
                if (s == null) return;
                boolean dark = isDark(((View) p.thisObject).getContext());
                if (s == STATE_ACTIVE) p.setResult(dark ? ACCENT : 0xFFFFFFFF);
            }
        });
    }

    // ---------- Blur ----------
    private void hookBlur(ClassLoader cl) {
        Class<?> c = XposedHelpers.findClass(BLUR, cl);

        if (FORCE_BLUR_SUPPORT) {
            hook(c, "supportsBlursOnWindows", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) { p.setResult(true); }
            });
        }

        // applyBlur(ViewRootImpl, int radius, boolean opaque)
        hook(c, "applyBlur", new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                if (p.args.length >= 3 && p.args[1] instanceof Integer) {
                    int r = (Integer) p.args[1];
                    if (r > 0) p.args[1] = Math.min(BLUR_MAX_PX, Math.round(r * BLUR_SCALE));
                }
                if (p.args.length >= 3 && p.args[2] instanceof Boolean) p.args[2] = false;
            }
        });
    }

    // ---------- Util ----------
    private static Integer stateOf(Object[] args) {
        if (args == null) return null;
        for (Object a : args) {
            if (a instanceof Integer) return (Integer) a;
            if (a != null && !(a instanceof Context) && !(a instanceof Boolean)) {
                try { return XposedHelpers.getIntField(a, "state"); } catch (Throwable ignored) { }
            }
        }
        return null;
    }

    private static boolean isDark(Context c) {
        return (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    private static void hook(Class<?> c, String name, XC_MethodHook cb) {
        int n = XposedBridge.hookAllMethods(c, name, cb).size();
        log((n > 0 ? "OK   " : "MISS ") + c.getSimpleName() + "." + name + " (" + n + ")");
    }

    private static final java.util.HashMap<String, Integer> COUNTS = new java.util.HashMap<>();

    private static void logLimited(String key, String m) {
        synchronized (COUNTS) {
            int c = COUNTS.containsKey(key) ? COUNTS.get(key) : 0;
            if (c >= 6) return;
            COUNTS.put(key, c + 1);
        }
        log(m);
    }

    /** Hanya mencatat argumen dan hasil method (maks 6 kali per method). */
    private static void trace(ClassLoader cl, String cls, String name) {
        try {
            Class<?> c = XposedHelpers.findClass(cls, cl);
            int n = XposedBridge.hookAllMethods(c, name, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    StringBuilder sb = new StringBuilder("TRACE " + c.getSimpleName() + "." + name + "(");
                    for (Object a : p.args) sb.append(String.valueOf(a)).append(", ");
                    sb.append(") = ").append(String.valueOf(p.getResult()));
                    logLimited(name, sb.toString());
                }
            }).size();
            log((n > 0 ? "OK   " : "MISS ") + c.getSimpleName() + "." + name + " (trace)");
        } catch (Throwable t) {
            log("FAIL trace " + cls + "." + name + ": " + t);
        }
    }

    private static void safe(String what, Runnable r) {
        try { r.run(); } catch (Throwable t) { log("FAIL " + what + ": " + t); }
    }

    private static void log(String m) { XposedBridge.log("[QSGlass] " + m); }
}
