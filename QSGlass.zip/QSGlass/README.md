# QS Glass (tahap 1) - OxygenOS 15 port

## Build
1. Buka folder ini di Android Studio (Ladybug atau lebih baru, JDK 17), tunggu Gradle sync.
2. Build > Build APK(s) -> `assembleDebug`. APK ada di `app/build/outputs/apk/debug/`.
3. Install APK ke HP.

## Aktifkan
1. LSPosed > Modul > QS Glass > aktifkan.
2. Scope: centang **System UI** (sudah dicantumkan otomatis, cek saja).
3. Restart SystemUI: `su -c "killall com.android.systemui"`, atau reboot.
4. Buka log LSPosed (menu Log > Modul), cari `[QSGlass]`.
   - `OK` = hook terpasang. `MISS` = method tidak ditemukan di build kamu. `FAIL` = error.

## Kalau SystemUI crash / bootloop
- LSPosed > nonaktifkan modul, lalu restart SystemUI.
- Kalau tidak bisa masuk HP: boot ke Safe Mode (tahan Vol Bawah saat logo muncul). Ini menonaktifkan modul Magisk termasuk LSPosed.
- Atau lewat adb/recovery: hapus modul Magisk LSPosed di `/data/adb/modules/`.

## Atur tampilan
Ubah konstanta di bagian atas `MainHook.java` (BLUR_SCALE, ACCENT, dll), build ulang.
